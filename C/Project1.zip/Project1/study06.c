#include<stdio.h>

int main() {
	int a = 100;
	double b = 3.14;
	char c = 'A';

	return 0;
}