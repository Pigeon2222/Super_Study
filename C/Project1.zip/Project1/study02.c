#include<stdio.h>

int main() {
	printf("%d ", 1 + 1);
	printf("%f ", 1.0 / 3);
	printf("%f ", 1 / 3);
	printf("%d ", 1 / 3);
	printf("%c ", 'A');
	printf("%d ", 'A');
	printf("%s ", "�̵���");
	printf("%c ", '��');

	return 0;
}