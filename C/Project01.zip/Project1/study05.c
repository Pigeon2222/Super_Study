#include<stdio.h>

int main() {
	printf("%d\n", 10 + 2);
	printf("%d\n", 10 - 2);
	printf("%d\n", 10 * 2);
	printf("%d\n", 10 / 2);
	printf("%d\n", 10 % 2);

	printf("%d\n", 10+2*5);
	printf("%d\n", (10+2)*5);

	printf("%d\n", 9&8);
	printf("%d\n", 9|8);
	printf("%d\n", 9^8);

	printf("%d\n", 8<<2);
	printf("%d\n", 8>>2);

	printf("\\");
	
	return 0;
}